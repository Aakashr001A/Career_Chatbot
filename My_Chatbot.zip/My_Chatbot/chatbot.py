# career_chatbot.py

def load_data():
    data = {}
    with open("career_data.txt", "r") as file:
        content = file.read().split("\n\n")  # Separate each block
        for block in content:
            lines = block.strip().split("\n")
            if len(lines) >= 4:
                interest = lines[0].split(": ")[1].strip()
                courses = lines[1].split(": ")[1].strip()
                duration = lines[2].split(": ")[1].strip()
                colleges = lines[3].split(": ")[1].strip()
                data[interest.lower()] = {
                    "Courses": courses,
                    "Duration": duration,
                    "Colleges": colleges
                }
    return data


def chatbot():
    print("🤖 Hello! I am your Career Guidance Chatbot.")
    print("Tell me, what is your interest area? (e.g., Computers, Business, Arts, Science, etc.)")

    data = load_data()

    while True:
        user_input = input("\nYou: ").lower()

        if user_input in ["exit", "quit", "bye"]:
            print("Chatbot: Goodbye! Best of luck with your career. 👋")
            break

        if user_input in data:
            info = data[user_input]
            print("\nChatbot: Based on your interest in", user_input.capitalize(), "👇")
            print("Courses:", info["Courses"])
            print("Duration:", info["Duration"])
            print("Top Colleges:", info["Colleges"])
        else:
            print("Chatbot: Sorry, I don't have data for that interest area. Try another one.")


if __name__ == "__main__":
    chatbot()
