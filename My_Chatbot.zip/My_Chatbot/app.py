from flask import Flask, render_template, request, jsonify
import os

app = Flask(__name__)

DATA_FILE = os.path.join(os.path.dirname(__file__), "career_data.txt")

def load_data():
    """Load career data into a dict by interest field (lowercased)."""
    data_by_field = {}
    if not os.path.exists(DATA_FILE):
        return data_by_field

    with open(DATA_FILE, "r", encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            parts = [p.strip() for p in line.split(",", 3)]
            if len(parts) != 4:
                # skip malformed lines safely
                continue
            course, field, duration, colleges = parts
            key = field.lower()
            entry = {
                "course": course,
                "duration": duration,
                "colleges": colleges
            }
            data_by_field.setdefault(key, []).append(entry)
    return data_by_field

# Load once at startup (reload on each request if you prefer dynamic updates)
CAREER_DB = load_data()

@app.route("/")
def home():
    # The page itself will show the initial bot prompt "What is your interest area?"
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def get_info():
    user_text = request.json.get("message", "").strip().lower()
    if not user_text:
        return jsonify({"reply": "Please tell me your interest area (e.g., Business, Computers, Arts)."}), 200

    # try to match interest by simple substring / exact match of known fields
    # also allow matching common words (like "computer", "computers", "coding")
    # check keys in CAREER_DB
    for field_key in CAREER_DB.keys():
        if field_key in user_text:
            entries = CAREER_DB[field_key]
            # build reply listing courses and details
            lines = [f"Matches for **{field_key.title()}**:"]
            for e in entries:
                lines.append(f"- {e['course']} — Duration: {e['duration']} — Colleges: {e['colleges']}")
            return jsonify({"reply": "\n".join(lines)}), 200

    # Try a keyword approach: check words in user_text for matching some field words
    # build a simple keyword map from the field names (you can expand this)
    keywords_map = {
        "computer": "computers",
        "computers": "computers",
        "software": "computers",
        "ai": "computers",
        "business": "business",
        "management": "business",
        "finance": "commerce",  # if you have commerce as field
        "arts": "arts",
        "art": "arts",
        "design": "design",
        "medical": "medical",
        "health": "medical",
        "hotel": "hospitality",
        "hospitality": "hospitality",
        "law": "law",
        "forensic": "forensics",
        "agriculture": "agriculture",
        "math": "mathematics",
        "sports": "sports"
    }
    for word, field in keywords_map.items():
        if word in user_text and field in CAREER_DB:
            entries = CAREER_DB[field]
            lines = [f"Based on '{word}', these courses match **{field.title()}**:"]
            for e in entries:
                lines.append(f"- {e['course']} — Duration: {e['duration']} — Colleges: {e['colleges']}")
            return jsonify({"reply": "\n".join(lines)}), 200

    # fallback
    return jsonify({"reply": "I didn't understand that interest. Please type one of: Business, Computers, Arts, Medical, Design, Hospitality, Law, Agriculture, Mathematics, Forensics, etc."}), 200

if __name__ == "__main__":
    # run with python app.py
    app.run(debug=True)
